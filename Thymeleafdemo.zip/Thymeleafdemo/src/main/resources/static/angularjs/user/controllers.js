
angular.module("userapp.controllers",[]).controller("UserCtrl", function($scope) {
	
		$scope.status = {
		    opened: false
		  };
		  $scope.today = function() {
		    $scope.dt = new Date();
		  };
		  $scope.today();	
		  
		  


		  $scope.setDate = function(year, month, day) {
		    $scope.dt = new Date(year, month, day);
		  };

		  $scope.dateOptions = {
		    formatYear: 'yyyy',
		    startingDay: 1
		  };
		
		  $scope.format = 'dd-MM-yyyy';

		  

	  
		  
		
});