angular.module("userapp", [
  "userapp.controllers",'ui.bootstrap','ui.bootstrap.tpls'
]);
