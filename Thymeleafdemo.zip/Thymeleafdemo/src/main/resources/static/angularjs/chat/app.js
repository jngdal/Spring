angular.module("chatApp", [
  "chatApp.controllers",
  "chatApp.services",'ui.bootstrap'
]);
