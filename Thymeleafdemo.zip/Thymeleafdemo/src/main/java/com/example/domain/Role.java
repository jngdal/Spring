package com.example.domain;

public enum Role {
	ROLE_USER
}
