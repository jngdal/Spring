package com.example.websocket;

public class HelloMessage {

	private String name;
	
	public String getName() {
		return name;
	}
}
