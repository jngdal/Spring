package com.example.testlogin;

public enum SocialMediaService {
	FACEBOOK,
    TWITTER
}
